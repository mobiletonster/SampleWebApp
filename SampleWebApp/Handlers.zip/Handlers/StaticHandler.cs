﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;

namespace SampleWebApp.Handlers
{
    public class StaticHandler : IHttpHandler
    {
        string _basePath = "C:/app/";
        bool IHttpHandler.IsReusable
        {
            get
            {
                return true;
            }
        }

        void IHttpHandler.ProcessRequest(HttpContext context)
        {
            var uri = context.Request.Url;
            var url = uri.AbsolutePath;


            if (uri.Segments.Last().Trim().EndsWith("/"))
            {
                // set default document to index.html
                // could loop through a series of default documents, but this works for now.
                url += "index.html";
            }
            var path = _basePath + url;

            if (!File.Exists(path))
            {
                context.Response.StatusCode = 404;
                context.Response.StatusDescription = "File Not Found";
                return;
            }

            // Find the MIME type
            string mimeType = MimeMapping.GetMimeMapping(path);
            context.Response.ContentType = mimeType;
            context.Response.WriteFile(path);

        }
    }
}